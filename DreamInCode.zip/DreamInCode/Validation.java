import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Validation {

static Boolean errorFound = false;
		
	
public static String validateWorksheet(List<UserAccount> userAccountList, ArrayList<LinkedHashMap<String, String>> worksheetUserAccounts)
{
	StringBuilder discrepancyLog =  new StringBuilder();
	errorFound = false;
	
	
	discrepancyLog.append("********Discrepancy Log********" + System.lineSeparator());
	

	return discrepancyLog.toString();
	
}

	
	
	
}
