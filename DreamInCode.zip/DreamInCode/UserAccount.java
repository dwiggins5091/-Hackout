
public class UserAccount {
	
	private String email = "";
	private String password = "";
	private String accountStatus = "";
	
	
	public UserAccount()
	{
		
	}
	
	public UserAccount(String anEmail, String accountStatus) 
	{
		email = anEmail;
		this.accountStatus = accountStatus;
	}
	
	public UserAccount(String anEmail, String password, String accountStatus) 
	{
		email = anEmail;
		this.password = password;
		this.accountStatus = accountStatus;
	}

	public void setAccountStatus(String status) {accountStatus = status;}
	public String getAccountStatus() {return accountStatus;}
	public String getEmail() {return email;}
	public String getPassword() {return password;}
	
}
