import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Validation {

static Boolean errorFound = false;
		
	
public static String validateWorksheet(List<UserAccount> userAccountList, ArrayList<LinkedHashMap<String, String>> worksheetUserAccounts)
{
	StringBuilder discrepancyLog =  new StringBuilder();
	errorFound = false;
	
	
	discrepancyLog.append("********Discrepancy Log********" + System.lineSeparator());
	
	
	for(int i = 0; i < userAccountList.size(); i++)
	{
		LinkedHashMap<String, String> worksheetUserAccountInfo = worksheetUserAccounts.get(i);
		UserAccount systemUserAccountInfo = userAccountList.get(i);
		
		
		if(!systemUserAccountInfo.getAccountStatus().equals(worksheetUserAccountInfo.get("AccountStatus")))
		{
			discrepancyLog.append("Discrepancy Identified for " + systemUserAccountInfo.getEmail() + ": "
					+ "Account Status Expected: " + worksheetUserAccountInfo.get("AccountStatus") + "; Actual: " + systemUserAccountInfo.getAccountStatus());
			discrepancyLog.append(System.lineSeparator());
			errorFound = true;
		}
		
	}
	
	if(errorFound == false)
	{
		discrepancyLog.append(System.lineSeparator() + "No Discrepancies Found");
	}
	
	return discrepancyLog.toString();
	
}

	
	
	
}
