import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;



public class FileReaderAndWriter {

static List<UserAccount> userAccounts = new ArrayList<>();
	
/*public static void main(String[]args) {
	
	String path = args[0];
	
	try {
		//readFile("C:\\Users\\dwigginsjr\\Desktop\\GeekOut_WorkOut\\GeekOut_WorkOut\\WorkOutTestAutomation\\user_accounts");
		readFile(path);
		
		for(UserAccount aUser : userAccounts)
		{
			System.out.println(aUser.getUserName() + "," + aUser.getPassword() + "," + aUser.getAccountStatus());			
		}
		
		writeFile("C:\\Users\\dwigginsjr\\Desktop\\GeekOut_WorkOut\\GeekOut_WorkOut\\WorkOutTestAutomation", "user_accounts-Updated");
		
		
	} catch (IOException e) {
		e.printStackTrace();
	}
	
}*/

/**
 * Method the reads a CSV file or a Text File with values split by commas an save those values to an object
 * @param path - Path to the File that needs to be read
 * @throws IOException
 */
public static void readFile(String path) throws IOException {
	
	File inputFile = null;
	List<String> parsedFile;
	
	if(path !=null)
	{
		inputFile = new File(path);
	}
	else
	{
		System.out.println("File Path Cannot Be Null or Empty");
		System.exit(-1);
	}
	
	parsedFile = FileUtils.readLines(inputFile, "UTF-8");
	
	for(String line : parsedFile)
	{
		System.out.println(line);
		String[] splitList = line.split(",");
		
		UserAccount aUserAccount = new UserAccount(splitList[0], "", splitList[2]);
		userAccounts.add(aUserAccount);
		
	}
	
}

public static void writeDiscrepancyFile(String path, String discrepancyLog) throws IOException
{
	
	Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
	SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMddHHmmss");
	
	File outputFile = new File(path, "DiscpancyLog_" + dateFormatter.format(timeStamp) +".txt");

	
	FileUtils.write(outputFile, discrepancyLog, "UTF-8", true);
	
}


public static void writeFile(String path, String fileName) throws IOException
{
	File outputFile = new File(path, fileName);
	StringBuilder userAccountLine = new StringBuilder();
	String newLine = System.lineSeparator();
	
	for(UserAccount aUser : userAccounts)
	{
		userAccountLine.append(aUser.getEmail() + "," + aUser.getPassword() + "," + aUser.getAccountStatus() + newLine);			
	}
	
	FileUtils.write(outputFile, userAccountLine.toString(), "UTF-8", true);
	
}
	
	
}
