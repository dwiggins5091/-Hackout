


import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.junit.ComparisonFailure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TestScriptDriver {

	public static void main(String[] args) {
		//ArrayList<LinkedHashMap<String, String>> worksheet = TestScriptParamHandler.convertSheetToHashMap(System.getProperty("user.dir")+"\\TestData.xlsx", "Sheet1");
		ArrayList<LinkedHashMap<String, String>> worksheet2 = TestScriptParamHandler.convertSheetToHashMap(System.getProperty("user.dir")+"\\TestData_HackOut.xlsx", "Sheet1");
		List<UserAccount> testedUserAccounts = new ArrayList<>();
				
		
		System.out.println("Executing test suite...");
		for(int i = 0; i < worksheet2.size(); i++) {
			System.out.println("Executing test script...");
			System.out.println("Testing with:" + "\nEmail: " + worksheet2.get(i).get("Email") + "\nPassword: " + worksheet2.get(i).get("Password"));
			//update with your username
			System.setProperty("webdriver.chrome.driver", "C:\\ACA Automation Java Library\\selenium\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			driver.get(System.getProperty("user.dir")+"\\Website\\Login\\Login - Hackathon Starter.html");
			
			driver.findElement(By.id("email")).sendKeys(worksheet2.get(i).get("Email"));
			driver.findElement(By.id("password")).sendKeys(worksheet2.get(i).get("Password")); 
			driver.findElements(By.id("submitbutton")).get(0).click();
			String bannerMessage = driver.findElement(By.xpath("//html//body//div[2]//div[1]//div")).getText();

			System.out.println("Output: " + bannerMessage);
				
			if(bannerMessage.equals("Success! You are logged in."))
			{
				UserAccount aUserAccount = new UserAccount(worksheet2.get(i).get("Email"), "active");
				testedUserAccounts.add(aUserAccount);
				
			}
			else if(bannerMessage.equals("Invalid email or password."))
			{
				UserAccount aUserAccount = new UserAccount(worksheet2.get(i).get("Email"), "deactivated");
				testedUserAccounts.add(aUserAccount);
				
			}
			
			
	/*		
			try
			{
				//assertEquals(bannerMessage, "Success! You are logged in.");
				//assertEquals(bannerMessage, "Invalid email or password.");
			}
			catch(ComparisonFailure cF)
			{
				System.out.println("Test Case Failed");
				
			}
			
  */
			
			driver.close();
			driver.quit();
			System.out.println("Exiting test script...");
			
		}
		
		String discrepancyLog = Validation.validateWorksheet(testedUserAccounts, worksheet2);
		
		
		try {
			
			FileReaderAndWriter.writeDiscrepancyFile("C:\\Users\\dwigginsjr\\Desktop\\GeekOut_WorkOut",discrepancyLog);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Exiting test suite...");
		
	}

}
